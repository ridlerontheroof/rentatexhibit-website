# Woods Crossing — AppFolio, UTM & operations add-on package

Add-on to the original handoff package (drop into the project root; nothing here
overwrites existing files).

## Contents
- `docs/APPFOLIO_INTEGRATION_PLAYBOOK.md` — direct AppFolio routing: availability feed,
  listing photos, guest-card lead push, showing scheduler, general "Tour" unit, prospect
  emails, bot guard, monitoring.
- `docs/UTM_ANALYTICS_PLAYBOOK.md` — visit-scoped attribution pipeline (landing URL →
  AppFolio lead source), the `Website (Token)` label convention, Google Ads gotchas,
  GA4-under-GTM event routing (the silent-drop trap), deferred tag loading, CSP for tags.
- `docs/OPERATIONS_LEARNINGS.md` — everything else not in the original package: Replit
  production serving (Express, trust proxy, CSP rollout), deploy-runtime observability,
  domain/redirect traps, alert & email operations, image/share-card pipeline, build &
  test discipline.

## Property-specific setup before building (see playbooks for detail)
1. Ask the leasing team to create a hidden "Tour" unit for Woods Crossing in AppFolio.
2. Confirm the exact property name AppFolio uses for Woods Crossing (unit_directory report).
3. Re-enter APPFOLIO_CLIENT_ID / APPFOLIO_CLIENT_SECRET as secrets (same values work —
   database-level; host `highlandrealestatepartners.appfolio.com`).
4. Confirm the default lead-source label wording (e.g. `Website (WoodsCrossing)`).
5. New GA4 property + GTM container for woodscrossingslc.com; grant the existing GA4
   service account Viewer on the new property for reporting.
