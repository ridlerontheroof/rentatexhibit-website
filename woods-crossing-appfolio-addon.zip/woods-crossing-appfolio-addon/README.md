# Woods Crossing — AppFolio add-on package

Add-on to the original handoff package (drop into the project root; nothing here
overwrites existing files).

- `docs/APPFOLIO_INTEGRATION_PLAYBOOK.md` — every lesson from the Exhibit On Superior
  site's direct AppFolio integrations: availability feed, listing photos, guest-card
  lead push, lead-source attribution, showing scheduler, general "Tour" unit, emails,
  bot guard, and monitoring. Use it to route leads/tours from the website straight to
  AppFolio (no highlandptrs.com hop).

Property-specific setup needed before building (see playbook for detail):
1. Ask the leasing team to create a hidden "Tour" unit for Woods Crossing in AppFolio.
2. Confirm the exact property name AppFolio uses for Woods Crossing (unit_directory report).
3. Re-enter APPFOLIO_CLIENT_ID / APPFOLIO_CLIENT_SECRET as secrets (same values work —
   they are database-level, database host `highlandrealestatepartners.appfolio.com`).
