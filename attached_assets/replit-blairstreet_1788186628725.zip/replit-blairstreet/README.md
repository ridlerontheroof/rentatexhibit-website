# Blair Street Apartments — liveatblairstreet.com

Static site package, ready for Replit (or any static host).

## Quick start on Replit
1. Create a new Repl → "HTML/CSS/JS" (static) — or Node if you prefer a server.
2. Upload this folder's contents to the Repl root.
3. Run `node scripts/download-assets.mjs` once to pull the property photos into `assets/img/` (do this BEFORE the old site is shut down — it downloads from the current live host).
4. Serve. Every page lives at its original URL (`/floor-plans/`, `/amenities/`, …) so existing Google indexing carries over 1:1 at DNS cutover. Keep trailing slashes.

## AppFolio integration (currently mock)
- `data/units.json` is placeholder inventory. `js/availability.js` has step-by-step swap instructions (listings feed URL, resident portal `/connect` link, per-unit application URLs).
- Anchors marked `data-appfolio="resident-portal"` and `data-appfolio="apply"` are the ones to point at AppFolio.
- The contact form posts nowhere yet (`data-todo` attribute) — wire it to a form handler or AppFolio guest cards.

## SEO already built in
- Unique title + meta description per page, canonicals, Open Graph
- JSON-LD: ApartmentComplex + FloorPlan (home, floor-plans, contact), FAQPage (fees-and-pets)
- `sitemap.xml`, `robots.txt`, `llms.txt`
- Matterport tour loads on click (fast LCP); images lazy-load

## At cutover
1. Verify domain in Google Search Console BEFORE switching DNS; submit `sitemap.xml`.
2. Update the Google Business Profile website link; keep the profile (it holds review equity).
3. Add the still-needed legal pages at their old slugs: `/ada/`, `/privacy-policy/`, `/licenses-and-disclosures/` (footer already links them).
4. Confirm distances/drive times marked in copy, and replace mock unit data with the live feed.
