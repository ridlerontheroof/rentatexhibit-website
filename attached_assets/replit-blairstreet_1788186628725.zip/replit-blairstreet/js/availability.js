// Availability feed — currently MOCK data from /data/units.json.
// TO GO LIVE WITH APPFOLIO:
// 1. In AppFolio: Settings > API Access (or ask AppFolio support to enable the Listings endpoint).
//    Your listings feed is at https://<yourcompany>.appfolio.com/listings.json (public) or via the AppFolio API with credentials.
// 2. Replace FEED_URL below with your feed and map their fields in normalize().
// 3. Resident Portal links: replace href="#" [data-appfolio="resident-portal"] anchors with
//    https://<yourcompany>.appfolio.com/connect (AppFolio Online Portal).
// 4. Apply links [data-appfolio="apply"]: use each listing's rental_application_url from the feed.
const FEED_URL = '/data/units.json';
function normalize(json) { return json.units; } // AppFolio: map listable_uid, marketing_title, market_rent, available_date, bedrooms, bathrooms, unit
function card(u) {
  return '<div class="unit"><div class="row"><span class="num">Unit ' + u.num + '</span><span class="avail">' + u.avail + '</span></div>' +
    '<div class="spec">' + u.spec + '</div>' +
    '<div class="foot"><span class="rent">' + u.rent + '<small>/mo</small></span><a class="apply" href="#" data-appfolio="apply">Apply</a></div></div>';
}
fetch(FEED_URL).then(r => r.json()).then(json => {
  const units = normalize(json);
  document.querySelectorAll('.units[id]').forEach(el => {
    const limit = parseInt(el.dataset.limit || '0', 10);
    el.innerHTML = (limit ? units.slice(0, limit) : units).map(card).join('');
  });
}).catch(() => {
  document.querySelectorAll('.units[id]').forEach(el => {
    el.innerHTML = '<p style="color:#8a93a0;font-size:15px">Availability is loading — call us at (801) 896-9844 for current openings.</p>';
  });
});
