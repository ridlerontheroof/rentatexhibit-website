// Downloads property photos from the current live site into /assets/img/.
// Run once on Replit: node scripts/download-assets.mjs
// NOTE: run this BEFORE the old site is decommissioned at closing — the source host goes away.
import { mkdir, writeFile } from 'node:fs/promises';
const images = {
  "two-bed-interior.jpg": "https://liveatblairstreet.com/wp-content/uploads/sites/239/2025/06/jmq7fa9hlfqbp5t6f2wbcvrvbuebsh5u.jpg.800x600.jpg",
  "one-bed-interior.jpg": "https://liveatblairstreet.com/wp-content/uploads/sites/239/2025/06/bess2etri99w5bsbgqsri6noek60r4kf.jpg.800x600.jpg",
  "living-area.jpg": "https://liveatblairstreet.com/wp-content/uploads/sites/239/2025/06/w4llcljvry3zqm9pyevxkymtg7bmfd6j.jpg.800x600.jpg",
  "interior.jpg": "https://liveatblairstreet.com/wp-content/uploads/sites/239/2025/06/6dz5kkp04nnqrpna1bgbpiob8sc5it7w.jpg.800x600.jpg",
  "kitchen.jpg": "https://liveatblairstreet.com/wp-content/uploads/sites/239/2025/06/3rcvtes0nmnf5mk18no7lk7qoagnouel.jpg.800x600.jpg",
  "living-room.jpg": "https://liveatblairstreet.com/wp-content/uploads/sites/239/2025/06/sfktol3o0f2ir8dz7ygonokd9omjl6yd.jpg.800x600.jpg"
};
await mkdir('assets/img', { recursive: true });
for (const [name, url] of Object.entries(images)) {
  const res = await fetch(url);
  if (!res.ok) { console.error('FAILED', name, url, res.status); continue; }
  await writeFile('assets/img/' + name, Buffer.from(await res.arrayBuffer()));
  console.log('saved assets/img/' + name);
}
console.log('Done. Consider converting to WebP and adding width/height attributes for best Core Web Vitals.');
