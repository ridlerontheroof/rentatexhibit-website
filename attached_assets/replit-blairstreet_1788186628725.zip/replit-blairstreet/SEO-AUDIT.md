# SEO / AEO Audit & Growth Plan — SSLC Portfolio
liveatwhitepinesapts.com · liveatblairstreet.com · Aug 2026

## 1 — Where both sites stand today
Both sites are the same WordPress template (Cornerstone Property multisite) and share the same defects:
- **Empty title tags** — homepage titles are literally "White Pines |" and "Live At Blair Street |". Zero keyword signal; terrible SERP click-through.
- **No meta descriptions** on any page.
- **Zero structured data** — no ApartmentComplex, FloorPlan, FAQPage, or LocalBusiness JSON-LD.
- **Mixed content** — most images load over insecure http://…cornerstoneproperty.host; those URLs die when that host is turned off at close.
- **Stock-photo soup** — Shutterstock alt text leaks into image SEO; Blair Street's hero is a Canva "Black Friday" Instagram graphic.
- **Portal link soup** — three conflicting resident logins (RentSGT, LoftLiving, RealPage OneSite) + RealPage leasing links.
- **Accessibility bloat, real a11y broken** — 40-language widget adds ~500 DOM nodes while user-scalable=0 blocks pinch-zoom (WCAG failure).
- **Thin, wrong copy** — Blair Street claims "Poplar Grove" (wrong neighborhood); typos ("quite neighborhood", "Blair Steet").

## 2 — URL continuity plan (nothing re-indexes)
- KEEP verbatim (both domains): /, /floor-plans/, /amenities/, /neighborhood/, /gallery/, /virtual-tours/, /contact/ — trailing slashes preserved. No redirects, no lost equity.
- NEW: /availability/ (AppFolio-fed), /fees-and-pets/ (fee transparency) — linked from nav + sitemap.
- REPLACE: RealPage apply links and all legacy portals with AppFolio listing + resident portal URLs (external — no SEO loss).
- KEEP slugs, refresh content: /ada/, /privacy-policy/, /licenses-and-disclosures/ with Highland Partners entity info.
- Images: re-host under /assets/ — no image-URL equity worth keeping (insecure host dies at cutover anyway).
- At cutover: keep both Google Business Profiles (review equity), update website links, verify both domains in Search Console BEFORE DNS switch.

## 3 — SEO fixes built into the new sites
- Keyword-real titles ("2 Bedroom Apartments in South Salt Lake, UT | White Pines Apartments") + unique 155-char meta descriptions.
- Full JSON-LD stack: ApartmentComplex (address, geo, amenityFeature, petsAllowed), FloorPlan per plan, FAQPage, breadcrumbs.
- Target converting queries: "apartments south salt lake", "2 bedroom apartments salt lake city under $1500", "apartments near Sugarhouse", "pet friendly apartments 84115" — far less competitive than "Salt Lake City".
- Descriptive image filenames + alt text, lazy loading, explicit dimensions (no CLS), WebP.
- XML sitemap + robots.txt per site, canonicals, Open Graph cards with real property photos.
- Cross-link the portfolio: each site links its sister property and highlandptrs.com.

## 4 — AEO: getting cited by AI answer engines
- FAQ blocks with FAQPage schema on main pages — number-dense answers (rent, deposit, pet fees, parking, utilities).
- /fees-and-pets/ as a definitive fee-answer page — AI engines favor this page type; almost no competitor has one.
- Fact-first copy: "White Pines is a 56-unit renovated community at 3560 S 300 E, 3.4 miles from Sugarhouse" instead of lifestyle filler.
- llms.txt + clean semantic HTML (real h1–h3 hierarchy, tables for fees).
- Availability rendered as crawlable HTML, not client-side-only injection (current mock loads via JS — when wiring AppFolio, prefer server-side rendering or prerendering for this page).

## 5 — Performance (Core Web Vitals)
- Static pages, no WordPress/plugin payload. Target <100KB HTML+CSS, LCP <1.5s (currently ~4s+ mobile).
- Accessibility widget dropped; replaced with actual accessible markup + working pinch-zoom.
- Matterport + Maps iframes load on click (facade pattern) — the two heaviest objects on the old sites.
- Self-hosted WebP images sized to containers; single font family, preloaded.

## 6 — Visual improvements & traffic drivers
- Price-first hero: rent, beds, "renovated" in the first viewport.
- Real photography over stock — the renovation story (down-to-studs bathrooms, stainless, new everything) is the best marketing asset; a half-day shoot of renovated units outperforms every other line item.
- "Check availability" CTA on every screen feeding /availability/.
- Google Business Profiles as a channel: post renovated-unit photos, answer the Q&A tab with FAQ content, keep hours accurate — map pack drives more apartment leads than blue links.
- ILS consistency: AppFolio syndication to Zillow/Apartments.com with byte-identical NAP + photos.
- Neighborhood pages as content moat: real distances/minutes to Sugarhouse, downtown, TRAX, I-15.

## Expected outcome
Same URLs = zero index loss at cutover; then title/schema/content fixes compound. Realistic 3–6 month path to top-3 map pack for "apartments south salt lake" and AI-answer citations for fee/pet/pricing queries neither site is eligible for today.
